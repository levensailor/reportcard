from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    name="io",
    version="0.01",
    author="Jeff Levensailor",
    author_email="jeff@levensailor.com",
    description="Python io",
    license="MIT",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/levensailor/io",
    keywords=["io"],
    packages=["io"],
    install_requires=[
        "requests==2.22.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
