from requests import Session

class io(object):
    def __init__(self, username, password):
        self.username = username
        self.password = password

    def test():
        print('success')